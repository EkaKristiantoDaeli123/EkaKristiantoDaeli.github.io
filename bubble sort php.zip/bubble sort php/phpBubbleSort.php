<?php

function bubble(array $array)
{
    $n = count($array);
    
    for($counter = 1; $counter < $n; $counter++) {
        for ($current = $n -1; $current >= $counter; $current--) {
            $next = $current - 1;

            if ($array[$next] <= $array[$current]) {
                continue;
            }
            
            $swap            = $array[$next];
            $array[$next]    = $array[$current];
            $array[$current] = $swap;
        }
    }
    
    return $array;
}

function selection(array $array)
{
    $n = count($array);

    for ($current = 0; $current < $n; $current++) {
        $lowestValueIndex = $current;
        $lowestValue      = $array[$current];

        for ($next = $current + 1; $next < $n; $next++) {
            if ($array[$next] < $lowestValue) {
                $lowestValueIndex = $next;
                $lowestValue      = $array[$next];
            }
        }
 
        $array[$lowestValueIndex] = $array[$current];
        $array[$current]          = $lowestValue;
    }
 
    return $array;
}

$input  = [255,1,22,3,45,5];
$output = [
    'bubble'    => bubble($input),
    'selection' => selection($input),
];

var_dump($output);